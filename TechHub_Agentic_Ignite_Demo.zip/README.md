# Retail Agents

A retail agent demo system using Microsoft Agent Framework

## Requirements

- Python 3.10 or higher
- pip

## Setup

### 1. Create virtual environment (first time only)

```bash
python -m venv venv
```

### 2. Activate virtual environment

```bash
source venv/bin/activate  # macOS/Linux
# or
venv\Scripts\activate     # Windows
```

### 3. Install dependencies

**Option A: Using requirements.txt (recommended)**
```bash
pip install -r requirements.txt
```

**Option B: Install in development mode**
```bash
pip install -e .
```

### 4. Install development tools (optional)

For code formatting and linting:

```bash
pip install black ruff flake8
```

### 5. Configure environment variables

```bash
cp .env.example .env
```

Edit the `.env` file with your configuration:
- Azure OpenAI credentials (API key, endpoint, deployment name)
- Langfuse credentials (public key, secret key, host)

## Usage

Launch DevUI and chat with agents:

```bash
python scripts/run_devui.py
```

Browser will automatically open at `http://localhost:8080` where you can chat with the agents.

## Development

### Code Formatting

```bash
# Format code with Black (PEP8 compliant)
black src/ scripts/

# Or use Ruff formatter
ruff format .
```

### Linting

```bash
# Lint with Ruff (recommended)
ruff check --fix src/ scripts/

# Or use Flake8
flake8 src/ scripts/
```

## Agent Architecture

- **David**: Conversation suggestion agent
- **Michael**: Supervisor agent routing to sub-agents
  - **Kelly**: Product discovery and recommendations
  - **Dwight**: Shopping cart management
  - **Meridith**: Order management and policies