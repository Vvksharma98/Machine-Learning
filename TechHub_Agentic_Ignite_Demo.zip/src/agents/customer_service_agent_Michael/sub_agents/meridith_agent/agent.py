"""Meridith agent implementation."""

import logging
from typing import Any, List

from dotenv import load_dotenv
from agent_framework import MCPStreamableHTTPTool
from common.config import get_magento_config, get_kb_config
from common.mcp import make_headers  # Added for JWT/static token support

from agents.base import BaseRetailAgent

load_dotenv(override=True)
logger = logging.getLogger(__name__)

ACCEPT_BOTH = "application/json, text/event-stream"


def _ensure_dual_accept(headers: dict | None) -> dict:
    """Ensure Accept and Content-Type headers are always included along with Authorization."""
    h = dict(headers or {})
    h["Accept"] = ACCEPT_BOTH
    h.setdefault("Content-Type", "application/json")
    return h


class MeridithAgent(BaseRetailAgent):
    """Meridith - A retail assistant agent for order management and support."""

    NAME = "Meridith"
    DESCRIPTION = (
        "Order management agent responsible for retrieving orders, handling cancellations, "
        "and providing policy or support-related information."
    )
    PROMPT_NAME = "meridith_agent"
    ENABLE_MEMORY = False

    def __init__(self, **kwargs: Any):
        """Initialize the Meridith agent."""
        tools = self._create_tools()
        kwargs.pop("user_id", None)
        kwargs.pop("mem0_client", None)
        super().__init__(tools=tools, **kwargs)

    def _create_tools(self) -> List[object]:
        """Create and configure MCP tools used by the Meridith agent."""
        tools: List[object] = []

        # Magento MCP → Order and catalog operations
        magento_cfg = get_magento_config()
        magento_headers = _ensure_dual_accept(make_headers(magento_cfg))

        tools.append(
            MCPStreamableHTTPTool(
                name="magento_mcp",
                description="Magento order/cart/catalog MCP endpoint",
                url=magento_cfg.url,
                headers=magento_headers,
                # Example:
                # stream=True,
                # stream_mode="sse",
                # timeout=30,
                # max_retries=2,
            )
        )

        # Knowledge Base MCP → Policy and FAQ queries
        kb_cfg = get_kb_config()
        kb_headers = _ensure_dual_accept(make_headers(kb_cfg))

        tools.append(
            MCPStreamableHTTPTool(
                name="kb_mcp",
                description="Knowledge Base policy/FAQ MCP endpoint",
                url=kb_cfg.url,
                headers=kb_headers,
                # Example:
                # stream=True,
                # stream_mode="sse",
                # timeout=30,
                # max_retries=2,
            )
        )

        return tools
