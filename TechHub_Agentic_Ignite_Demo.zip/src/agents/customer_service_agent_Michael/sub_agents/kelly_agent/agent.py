"""Kelly agent implementation."""

import logging
from typing import Any, List

from dotenv import load_dotenv
from agent_framework import MCPStreamableHTTPTool
from common.config import get_magento_config, get_kb_config
from common.mcp import make_headers  # Added for JWT/static token support

from agents.base import BaseRetailAgent

load_dotenv(override=True)
logger = logging.getLogger(__name__)

ACCEPT_BOTH = "application/json, text/event-stream"


def _ensure_dual_accept(headers: dict | None) -> dict:
    """Ensure Accept and Content-Type headers are always included along with Authorization."""
    h = dict(headers or {})
    h["Accept"] = ACCEPT_BOTH
    h.setdefault("Content-Type", "application/json")
    return h


class KellyAgent(BaseRetailAgent):
    """Kelly - A retail assistant agent for product discovery and knowledge queries."""

    NAME = "Kelly"
    DESCRIPTION = (
        "Product discovery agent responsible for searching, comparing, "
        "recommending products, and adding items to the cart."
    )
    PROMPT_NAME = "kelly_agent"
    ENABLE_MEMORY = False

    def __init__(self, **kwargs: Any):
        """Initialize the Kelly agent."""
        tools = self._create_tools()
        kwargs.pop("user_id", None)
        kwargs.pop("mem0_client", None)
        super().__init__(tools=tools, **kwargs)

    def _create_tools(self) -> List[object]:
        """Create and configure MCP tools used by the Kelly agent."""
        tools: List[object] = []

        # Magento MCP → Product search and catalog endpoints
        magento_cfg = get_magento_config()
        magento_headers = _ensure_dual_accept(make_headers(magento_cfg))

        tools.append(
            MCPStreamableHTTPTool(
                name="magento_mcp",
                description="Magento catalog/search MCP endpoint",
                url=magento_cfg.url,
                headers=magento_headers,
                # Example:
                # stream=True,
                # stream_mode="sse",
                # timeout=30,
                # max_retries=2,
            )
        )

        # Knowledge Base MCP → FAQ and documentation lookup
        kb_cfg = get_kb_config()
        kb_headers = _ensure_dual_accept(make_headers(kb_cfg))

        tools.append(
            MCPStreamableHTTPTool(
                name="kb_mcp",
                description="Knowledge Base docs/FAQ MCP endpoint",
                url=kb_cfg.url,
                headers=kb_headers,
                # Example:
                # stream=True,
            )
        )

        return tools
