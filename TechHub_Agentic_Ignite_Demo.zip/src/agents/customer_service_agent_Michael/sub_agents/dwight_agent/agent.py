"""Dwight agent implementation."""

import logging
from typing import Any, List

from dotenv import load_dotenv
from agent_framework import MCPStreamableHTTPTool
from common.config import get_magento_config
from common.mcp import make_headers  # Added for JWT/static token support

from agents.base import BaseRetailAgent

load_dotenv(override=True)
logger = logging.getLogger(__name__)

ACCEPT_BOTH = "application/json, text/event-stream"


def _ensure_dual_accept(headers: dict | None) -> dict:
    """Ensure Accept and Content-Type headers are always included along with Authorization."""
    h = dict(headers or {})
    h["Accept"] = ACCEPT_BOTH
    h.setdefault("Content-Type", "application/json")
    return h


class DwightAgent(BaseRetailAgent):
    """Dwight - A retail assistant agent handling shopping cart operations."""

    NAME = "Dwight"
    DESCRIPTION = (
        "Shopping cart management agent handling cart display, "
        "quantity updates, and order placement."
    )
    PROMPT_NAME = "dwight_agent"
    ENABLE_MEMORY = False

    def __init__(self, **kwargs: Any):
        """Initialize the Dwight agent."""
        tools = self._create_tools()
        kwargs.pop("user_id", None)
        kwargs.pop("mem0_client", None)
        super().__init__(tools=tools, **kwargs)

    def _create_tools(self) -> List[object]:
        """Create and configure MCP tools used by the agent."""
        tools: List[object] = []

        # Magento MCP → MCPStreamableHTTPTool
        magento_cfg = get_magento_config()
        magento_headers = _ensure_dual_accept(make_headers(magento_cfg))

        tools.append(
            MCPStreamableHTTPTool(
                name="magento_mcp",
                description="Magento cart/catalog MCP endpoint",
                url=magento_cfg.url,  # e.g., https://.../mcp/
                headers=magento_headers,
                # stream=True,
                # stream_mode="sse",
                # timeout=30,
                # max_retries=2,
            )
        )

        return tools
