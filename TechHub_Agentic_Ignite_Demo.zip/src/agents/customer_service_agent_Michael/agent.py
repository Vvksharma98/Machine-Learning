"""Michael agent implementation."""

import os
from typing import Any

from mem0 import AsyncMemory

from agents.base import BaseRetailAgent


class MichaelAgent(BaseRetailAgent):
    """Michael - A retail assistant agent."""

    NAME = "Michael"
    DESCRIPTION = (
        "Supervisor agent that routes queries to specialized sub-agents: "
        "Kelly (products), Dwight (cart), Meridith (orders/policies)"
    )
    PROMPT_NAME = "michael_agent"
    ENABLE_MEMORY = True

    def __init__(
        self,
        user_id: str | None = None,
        mem0_client: AsyncMemory | None = None,
        **kwargs: Any,
    ):
        """Initialize Michael agent with sub-agent tools."""
        resolved_user_id = (
            user_id
            or kwargs.pop("user_id", None)
            or os.getenv("DEFAULT_USER_ID")
            or "default_user"
        )

        tools = self._create_sub_agent_tools()

        super().__init__(
            tools=tools,
            user_id=resolved_user_id,
            mem0_client=mem0_client,
            **kwargs,
        )

    def _create_sub_agent_tools(self) -> list[Any]:
        """Instantiate sub-agents and expose them as tools."""
        from agents.customer_service_agent_Michael.sub_agents.dwight_agent.agent import (
            DwightAgent,
        )
        from agents.customer_service_agent_Michael.sub_agents.kelly_agent.agent import (
            KellyAgent,
        )
        from agents.customer_service_agent_Michael.sub_agents.meridith_agent.agent import (
            MeridithAgent,
        )

        # Sub-agents are instantiated without user_id/mem0_client;
        dwight = DwightAgent()
        kelly = KellyAgent()
        meridith = MeridithAgent()

        return [
            dwight.agent.as_tool(
                name="consult_dwight",
                arg_name="query",
                arg_description=(
                    "Cart-related query for displaying items, updating quantities, or placing orders. "
                    "Dwight manages shopping cart operations including: viewing cart contents with get_cart_totals, "
                    "updating item quantities with update_cart_items, and placing orders with place_order_for_cart "
                    "(requires user confirmation)."
                ),
            ),
            kelly.agent.as_tool(
                name="consult_kelly",
                arg_name="query",
                arg_description=(
                    "Product discovery or recommendation query. Kelly assists with: finding products via "
                    "search_products and product_knowledge_base, comparing products in tabular format, "
                    "suggesting alternatives, and adding items to cart. Always returns multiple product options (5) "
                    "with details including product name, description, links, images, prices, and comparison summaries."
                ),
            ),
            meridith.agent.as_tool(
                name="consult_meridith",
                arg_name="query",
                arg_description=(
                    "Order management or policy inquiry. Meridith handles: retrieving specific orders by Order ID "
                    "with retrieve_order_by_id, fetching last 5 orders with retrieve_recent_orders, cancelling orders "
                    "with cancel_order (requires confirmation), and providing company policy information via "
                    "policy_details_knowledge_base for topics like cancellation and shipping policies."
                ),
            ),
        ]
