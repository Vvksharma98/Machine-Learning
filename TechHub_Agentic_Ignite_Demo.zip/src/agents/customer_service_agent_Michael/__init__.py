"""Michael agent module."""

from .agent import MichaelAgent

__all__ = ["MichaelAgent"]
