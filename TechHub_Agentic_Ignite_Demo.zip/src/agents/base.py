"""Base agent class for all retail agents."""

import os
from typing import Any

from agent_framework import ChatAgent
from agent_framework.azure import AzureOpenAIChatClient
from mem0 import AsyncMemory

from common import get_azure_openai_config, get_prompt
from common.memory import build_mem0_provider


class BaseRetailAgent:
    """Base class for all retail agents with shared functionality."""

    # Subclasses should override these
    NAME: str = "BaseAgent"
    DESCRIPTION: str = "A base retail agent"
    PROMPT_NAME: str = "base_agent"
    ENABLE_MEMORY: bool = False

    def __init__(
        self,
        temperature: float | None = None,
        max_tokens: int | None = None,
        tools: list[Any] | None = None,
        user_id: str | None = None,
        mem0_client: AsyncMemory | None = None,
        **kwargs: Any,
    ):
        """Initialize base agent.

        Args:
            temperature: Sampling temperature (optional).
            max_tokens: Maximum tokens to generate (optional).
            tools: List of tools/functions for the agent (optional).
            user_id: Identifier used to scope mem0 memories.
            mem0_client: Optional pre-configured mem0 client instance (required if ENABLE_MEMORY=True).
            kwargs: Additional ChatAgent parameters.
        """
        # Get Azure OpenAI config
        azure_config = get_azure_openai_config()

        # Get prompt from Langfuse
        instructions = get_prompt(self.PROMPT_NAME)

        # Setup mem0 context if enabled
        context_provider = None
        self.mem0_client: AsyncMemory | None = None
        self.user_id: str | None = None

        if self.ENABLE_MEMORY:
            self.user_id = (
                user_id or os.getenv("DEFAULT_USER_ID") or "default_user"
            )

            if mem0_client is None:
                raise ValueError(
                    f"{self.__class__.__name__} requires mem0_client. "
                    "Call 'await build_mem0_client()' and pass it as argument."
                )

            self.mem0_client = mem0_client
            context_provider = build_mem0_provider(
                user_id=self.user_id,
                mem0_client=self.mem0_client,
            )

        # Create Azure OpenAI client
        chat_client = AzureOpenAIChatClient(
            api_key=azure_config.api_key,
            endpoint=azure_config.endpoint,
            deployment_name=azure_config.deployment_name,
        )

        # Create agent
        self.agent = ChatAgent(
            chat_client=chat_client,
            name=self.NAME,
            description=self.DESCRIPTION,
            instructions=instructions,
            temperature=temperature,
            max_tokens=max_tokens,
            tools=tools,
            context_providers=context_provider,
            **kwargs,
        )
