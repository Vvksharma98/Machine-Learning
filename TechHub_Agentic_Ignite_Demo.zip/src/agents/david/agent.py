"""David agent implementation."""

import os
from typing import Any

from mem0 import AsyncMemory

from agents.base import BaseRetailAgent


class DavidAgent(BaseRetailAgent):
    """David - A retail assistant agent."""

    NAME = "David"
    DESCRIPTION = (
        "Conversation suggestion agent that analyzes chat history and recommends next steps "
        "based on available agent capabilities"
    )
    PROMPT_NAME = "david_agent"
    ENABLE_MEMORY = True

    def __init__(
        self,
        user_id: str | None = None,
        mem0_client: AsyncMemory | None = None,
        **kwargs: Any,
    ):
        """Initialize David agent with Michael as a tool."""
        resolved_user_id = (
            user_id
            or kwargs.get("user_id")
            or os.getenv("DEFAULT_USER_ID")
            or "default_user"
        )

        tools = self._create_tools(
            user_id=resolved_user_id,
            mem0_client=mem0_client,
        )

        super().__init__(
            tools=tools,
            user_id=resolved_user_id,
            mem0_client=mem0_client,
            **kwargs,
        )

    def _create_tools(
        self,
        user_id: str,
        mem0_client: AsyncMemory | None,
    ) -> list[Any]:
        """Expose Michael as a tool with shared memory context."""
        from agents.customer_service_agent_Michael.agent import MichaelAgent

        michael_agent = MichaelAgent(
            user_id=user_id,
            mem0_client=mem0_client,
        )

        return [
            michael_agent.agent.as_tool(
                name="consult_michael",
                arg_name="query",
                arg_description=(
                    "Any shopping-related query that needs to be routed to specialized agents. "
                    "Michael supervises and routes queries to: Kelly (product search, comparison, "
                    "recommendations, adding to cart), Dwight (cart operations: view, update quantities, "
                    "place orders), or Meridith (order management: retrieval, cancellation, and policy information)."
                ),
            ),
        ]
