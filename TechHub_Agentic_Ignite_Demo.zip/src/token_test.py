from common.config_mcp import get_magento_config

cfg = get_magento_config()
print("URL  :", cfg.url)
print("Auth :", cfg.make_headers()["Authorization"])
