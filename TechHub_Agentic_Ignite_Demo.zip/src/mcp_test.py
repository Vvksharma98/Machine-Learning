import json
import sys
import traceback
import requests

from common.config import (
    get_magento_config,
    get_kb_config,
)

from common.mcp import as_hosted_mcp_kwargs_with_session, fetch_mcp_session_id

ACCEPT_BOTH = "application/json, text/event-stream"


def _headers_accept_both(base_headers: dict) -> dict:
    h = dict(base_headers or {})
    h["Accept"] = ACCEPT_BOTH
    h["Content-Type"] = "application/json"
    return h


def _print_banner(title: str):
    print("\n" + "=" * 80)
    print(title)
    print("=" * 80)


def _post_json(url: str, headers: dict, payload: dict, timeout: int = 15):
    return requests.post(
        url, headers=headers, data=json.dumps(payload), timeout=timeout
    )


def _smoke_sequence(cfg_name: str, cfg_factory) -> bool:
    _print_banner(f"[{cfg_name}] starting authentication test (Accept BOTH)")
    try:
        cfg = cfg_factory()

        sid = fetch_mcp_session_id(cfg)
        print(f"[{cfg_name}] mcp-session-id acquired: {sid}")

        kwargs = as_hosted_mcp_kwargs_with_session(cfg)
        headers = _headers_accept_both(kwargs["headers"])

        print(f"[{cfg_name}] url         = {kwargs['url']}")
        print(f"[{cfg_name}] approval    = {kwargs['approval_mode']}")
        print(f"[{cfg_name}] Accept      = {headers['Accept']}")
        print(f"[{cfg_name}] CT          = {headers['Content-Type']}")
        print(f"[{cfg_name}] has Auth    = {'Authorization' in headers}")
        print(f"[{cfg_name}] has session = {'mcp-session-id' in headers}")

        init_payload = {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "initialize",
            "params": {
                "client": {"name": "auth-smoke-test", "version": "1.0"},
                "capabilities": {},
            },
        }
        resp = _post_json(kwargs["url"], headers, init_payload)
        print(f"[{cfg_name}] initialize -> HTTP {resp.status_code}")
        if resp.status_code in (401, 403, 406):
            print(f"[{cfg_name}] failed (status={resp.status_code})")
            print(f"[{cfg_name}] headers: {dict(resp.headers)}")
            print(f"[{cfg_name}] body   : {resp.text[:500]}")
            return False
        if not (200 <= resp.status_code < 400):
            print(f"[{cfg_name}] unexpected status={resp.status_code}")
            print(f"[{cfg_name}] body: {resp.text[:500]}")
            return False

        tools_payload = {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/list",
            "params": {},
        }
        resp2 = _post_json(kwargs["url"], headers, tools_payload)
        print(f"[{cfg_name}] tools/list  -> HTTP {resp2.status_code}")
        if resp2.status_code == 406:
            print(
                f"[{cfg_name}] 406 again. Server strictly requires dual Accept."
            )
            return False
        if resp2.status_code in (401, 403):
            print(f"[{cfg_name}] auth failed on tools/list")
            print(f"[{cfg_name}] body: {resp2.text[:500]}")
            return False

        if 200 <= resp2.status_code < 400:
            print(f"[{cfg_name}] authentication OK & tools reachable")
            return True

        print(
            f"[{cfg_name}] unexpected status on tools/list: {resp2.status_code}"
        )
        print(f"[{cfg_name}] body: {resp2.text[:500]}")
        return False

    except Exception as e:
        print(f"[{cfg_name}] exception during test: {e}")
        traceback.print_exc()
        return False


def main():
    ok_all = True
    ok_all &= _smoke_sequence("Magento MCP", get_magento_config)
    ok_all &= _smoke_sequence("KnowledgeBase MCP", get_kb_config)

    print("\n" + "-" * 80)
    print(" ALL AUTH TESTS PASSED" if ok_all else " SOME AUTH TESTS FAILED")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
