# mcp.py
from __future__ import annotations

import os
import time
import json
import inspect
from dataclasses import dataclass
from typing import Optional, Dict

import requests
from authlib.jose import JsonWebToken
from dotenv import load_dotenv

from common.config import MCPToolConfig

load_dotenv(override=True)

ACCEPT_BOTH = "application/json, text/event-stream"
JWT_DEFAULT_LEEWAY = int(os.getenv("JWT_LEEWAY_SECONDS", "60"))

# ------------------------------ helpers ------------------------------


def _ensure_dual_accept(headers: Dict[str, str]) -> Dict[str, str]:
    h = dict(headers or {})
    h["Accept"] = ACCEPT_BOTH
    h.setdefault("Content-Type", "application/json")
    return h


# ------------------------------ token provider ------------------------------


@dataclass
class JWTRS256TokenProvider:
    private_key_env: str
    # Default to short lifespan (e.g., 3600s). Override with env: JWT_TTL_SECONDS if needed.
    expires_in_seconds: int = int(os.getenv("JWT_TTL_SECONDS", "31540000"))
    audience_env: Optional[str] = None
    kid_env: Optional[str] = None

    def _normalize_pem(self, s: str) -> str:
        s = inspect.cleandoc(s)
        return s.replace("\\n", "\n") if "\\n" in s else s

    def generate(
        self,
        iss: Optional[str] = None,
        sub: Optional[str] = None,
        audience: Optional[str] = None,
    ) -> str:
        key_raw = os.getenv(self.private_key_env)
        if not key_raw:
            raise RuntimeError(
                f"Missing private key env: {self.private_key_env}"
            )

        private_key = self._normalize_pem(key_raw)
        now = int(time.time())
        leeway = JWT_DEFAULT_LEEWAY

        payload = {
            "iss": iss,
            "sub": sub,
            "iat": now - leeway,  # clock skew対策
            "nbf": now - leeway,  # clock skew対策
            "exp": now + self.expires_in_seconds,
        }

        # 優先度: 明示引数 > ENV > なし
        if audience:
            payload["aud"] = audience

        header = {"alg": "RS256", "typ": "JWT"}
        # kid は任意
        return (
            JsonWebToken(["RS256"])
            .encode(header, payload, key=private_key)
            .decode("utf-8")
        )


# ------------------------------ header builder (JWT or static) ------------------------------


def make_headers(cfg: MCPToolConfig) -> Dict[str, str]:
    """
    cfg に基づき Authorization ヘッダを生成。
    - 静的トークン: cfg.bearer_token_env
    - JWT (RS256): cfg.private_key_env を利用し、aud/iss/sub は ENV もしくは既定値を使う
    """
    # 1) 静的トークン
    if cfg.bearer_token_env:
        tok = (
            (os.getenv(cfg.bearer_token_env) or "")
            .strip()
            .strip('"')
            .strip("'")
        )
        if tok:
            return {"Authorization": f"Bearer {tok}"}

    # 2) JWT 生成
    if cfg.private_key_env:
        key = cfg.name.upper().replace(" ", "_").replace("-", "_")
        provider = JWTRS256TokenProvider(
            private_key_env=cfg.private_key_env,
            audience_env=f"{key}_JWT_AUD",
            kid_env=f"{key}_JWT_KID",
        )

        # aud は ENV が無ければ 接続先URL(cfg.url) を既定として使う（末尾スラ含む）
        try:
            audience_default = cfg.url
        except Exception:
            audience_default = None

        jwt_token = provider.generate(
            iss=cfg.iss or os.getenv(f"{key}_JWT_ISS"),
            sub=cfg.sub or os.getenv(f"{key}_JWT_SUB"),
            audience=os.getenv(f"{key}_JWT_AUD") or audience_default,
        )
        return {"Authorization": f"Bearer {jwt_token}"}

    # どちらも無い場合
    raise RuntimeError(
        f"No valid auth for {cfg.name}. Set {cfg.bearer_token_env or '<STATIC_TOKEN_ENV>'} "
        f"or {cfg.private_key_env or '<PRIVATE_KEY_ENV>'} in environment."
    )


# ------------------------------ HostedMCPTool kwargs helpers ------------------------------


def as_hosted_mcp_kwargs(cfg: MCPToolConfig) -> Dict[str, object]:
    auth = make_headers(cfg)
    if "Authorization" not in auth or not auth["Authorization"]:
        raise RuntimeError(
            f"Authorization header not generated for {cfg.name}"
        )

    headers = {"Authorization": auth["Authorization"]}
    return {
        "name": cfg.name,
        "url": cfg.url,  # 末尾スラは cfg.url が保証
        "approval_mode": cfg.approval_mode,
        "headers": headers,  # top-level
        "additional_properties": {  # 一部実装は additional_properties.headers を参照する
            "headers": headers
        },
    }


# ------------------------------ session (mcp-session-id) helpers [smoke用途] ------------------------------


def fetch_mcp_session_id(cfg: MCPToolConfig, timeout: int = 15) -> str:
    """POST initialize を叩き、レスポンスヘッダから `mcp-session-id` を取得する。"""
    headers = _ensure_dual_accept(make_headers(cfg))

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {
            "client": {"name": "agent-handshake", "version": "1.0"},
            "capabilities": {},
        },
    }

    # 通常の POST
    r = requests.post(
        cfg.url, headers=headers, data=json.dumps(payload), timeout=timeout
    )
    sid = r.headers.get("mcp-session-id")
    if sid:
        return sid

    # stream=True で再試行
    rs = requests.post(
        cfg.url,
        headers=headers,
        data=json.dumps(payload),
        stream=True,
        timeout=timeout,
    )
    sid = rs.headers.get("mcp-session-id")
    if sid:
        return sid

    raise RuntimeError(
        "mcp-session-id not found in initialize response headers"
    )


def as_hosted_mcp_kwargs_with_session(cfg: MCPToolConfig) -> Dict[str, object]:
    """HostedMCPTool 用 kwargs を構築しつつ、初回 handshake で mcp-session-id を注入（スモーク用）"""
    headers = _ensure_dual_accept(make_headers(cfg))
    sid = fetch_mcp_session_id(cfg)
    headers["mcp-session-id"] = sid

    return {
        "name": cfg.name,
        "url": cfg.url,
        "approval_mode": cfg.approval_mode,
        "headers": headers,
    }


# ------------------------------ simple smoke (manual run) ------------------------------
# if __name__ == "__main__":
#     from config import get_magento_config
#     magento = get_magento_config()
#     kwargs = as_hosted_mcp_kwargs_with_session(magento)
#     print(kwargs)
