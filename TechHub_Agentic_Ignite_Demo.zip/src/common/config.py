"""Common configuration shared across all agents."""

from __future__ import annotations
import os
from dataclasses import dataclass
from functools import lru_cache
from typing import Optional, Dict
from dotenv import load_dotenv

load_dotenv(override=True)


# ------------------------------ minimal helpers for MCP_URL ------------------------------


def _with_trailing_slash(url: str) -> str:
    return url if url.endswith("/") else url + "/"


def _compose_mcp_url(base: str, method: str) -> str:
    base = base.rstrip("/")
    method = method.strip("/")
    return _with_trailing_slash(f"{base}/{method}")


# ------------------------------ config ------------------------------
@dataclass
class LangfuseConfig:
    """Langfuse configuration."""

    public_key: str
    secret_key: str
    host: str

    @classmethod
    def from_env(cls) -> "LangfuseConfig":
        """Load from environment variables."""
        public_key = os.getenv("LANGFUSE_PUBLIC_KEY")
        secret_key = os.getenv("LANGFUSE_SECRET_KEY")
        host = os.getenv("LANGFUSE_HOST")

        if not all([public_key, secret_key, host]):
            raise ValueError(
                "Missing required Langfuse environment variables. "
                "Please set LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY, "
                "and LANGFUSE_HOST"
            )

        assert public_key is not None
        assert secret_key is not None
        assert host is not None

        return cls(
            public_key=public_key,
            secret_key=secret_key,
            host=host,
        )


@dataclass
class AzureOpenAIConfig:
    """Azure OpenAI configuration (for agents via LiteLLM)."""

    api_key: str
    endpoint: str
    deployment_name: str

    @classmethod
    def from_env(cls) -> "AzureOpenAIConfig":
        """Load from environment variables."""
        api_key = os.getenv("AZURE_OPENAI_API_KEY")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        deployment_name = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")

        if not all([api_key, endpoint, deployment_name]):
            raise ValueError(
                "Missing required Azure OpenAI environment variables. "
                "Please set AZURE_OPENAI_API_KEY, AZURE_OPENAI_ENDPOINT, "
                "and AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"
            )

        assert api_key is not None
        assert endpoint is not None
        assert deployment_name is not None

        return cls(
            api_key=api_key,
            endpoint=endpoint,
            deployment_name=deployment_name,
        )


@dataclass
class Mem0AzureOpenAIConfig:
    """Azure OpenAI configuration for mem0 (direct endpoint, not LiteLLM)."""

    api_key: str
    endpoint: str
    chat_deployment: str
    embedding_deployment: str
    api_version: str = "2024-10-21"

    @classmethod
    def from_env(cls) -> "Mem0AzureOpenAIConfig":
        """Load from environment variables."""
        api_key = os.getenv("MEM0_AZURE_OPENAI_API_KEY")
        endpoint = os.getenv("MEM0_AZURE_OPENAI_ENDPOINT")
        chat_deployment = os.getenv("MEM0_AZURE_OPENAI_CHAT_DEPLOYMENT")
        embedding_deployment = os.getenv(
            "MEM0_AZURE_OPENAI_EMBEDDING_DEPLOYMENT"
        )

        if not all([api_key, endpoint, chat_deployment, embedding_deployment]):
            raise ValueError(
                "Missing required mem0 Azure OpenAI environment variables. "
                "Please set MEM0_AZURE_OPENAI_API_KEY, MEM0_AZURE_OPENAI_ENDPOINT, "
                "MEM0_AZURE_OPENAI_CHAT_DEPLOYMENT, and MEM0_AZURE_OPENAI_EMBEDDING_DEPLOYMENT"
            )

        assert api_key is not None
        assert endpoint is not None
        assert chat_deployment is not None
        assert embedding_deployment is not None

        return cls(
            api_key=api_key,
            endpoint=endpoint,
            chat_deployment=chat_deployment,
            embedding_deployment=embedding_deployment,
        )


@dataclass
class AzureAIFoundryConfig:
    """Azure AI Foundry configuration."""

    project_endpoint: str

    @classmethod
    def from_env(cls) -> "AzureAIFoundryConfig":
        """Load from environment variables."""
        endpoint = os.getenv("AZURE_AI_FOUNDRY_ENDPOINT")

        if not endpoint:
            raise ValueError(
                "Missing required Azure AI Foundry environment variable. "
                "Please set AZURE_AI_FOUNDRY_ENDPOINT"
            )

        return cls(project_endpoint=endpoint)


@dataclass
class AzureSearchConfig:
    """Azure AI Search configuration."""

    service_name: str
    api_key: str
    collection_name: str = "memories"
    embedding_dims: int = 1536

    @classmethod
    def from_env(cls) -> "AzureSearchConfig":
        """Load Azure AI Search configuration."""
        service_name = os.getenv("AZURE_SEARCH_SERVICE_NAME")
        api_key = os.getenv("AZURE_SEARCH_API_KEY")

        if not all([service_name, api_key]):
            raise ValueError(
                "Missing AZURE_SEARCH_SERVICE_NAME or AZURE_SEARCH_API_KEY"
            )

        return cls(service_name=service_name, api_key=api_key)


@dataclass
class AzureOpenAIEmbeddingConfig:
    """Azure OpenAI embedding configuration (deprecated - use Mem0AzureOpenAIConfig)."""

    deployment: str
    endpoint: str
    api_key: str
    api_version: str = "2024-10-21"
    embedding_dims: int = 1536

    @classmethod
    def from_env(cls) -> "AzureOpenAIEmbeddingConfig":
        """Load Azure OpenAI embedding configuration."""
        deployment = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT")
        endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
        api_key = os.getenv("AZURE_OPENAI_API_KEY")

        if not all([deployment, endpoint, api_key]):
            raise ValueError(
                "Missing required Azure OpenAI embedding environment variables. "
                "Please set AZURE_OPENAI_EMBEDDING_DEPLOYMENT, AZURE_OPENAI_ENDPOINT, "
                "and AZURE_OPENAI_API_KEY"
            )

        return cls(
            deployment=deployment,
            endpoint=endpoint,
            api_key=api_key,
        )


@dataclass
class MCPToolConfig:
    """Configuration for a single MCP tool endpoint (e.g., Magento or KB)."""

    # Display name (for logging / HostedMCPTool.name)
    name: str

    # Connection
    base_url: str  # e.g., https://magento-tools.example.com
    connection_method: str  # e.g., "mcp" (server-dependent)

    # Auth
    approval_mode: str  # "never_require" | "always_require"
    bearer_token_env: Optional[str] = None  # static token env key
    private_key_env: Optional[str] = None  # RSA key env key, if generating JWT

    # Optional identity claims for JWT
    iss: Optional[str] = None
    sub: Optional[str] = None

    # Defaults for missing envs (mainly for local dev)
    default_connection_method: str = "mcp"
    default_approval_mode: str = "never_require"

    @classmethod
    def from_env(
        cls,
        *,
        name: str,
        base_url_env: str,
        connection_method_env: str,
        approval_mode_env: str,
        bearer_token_env: Optional[str] = None,
        private_key_env: Optional[str] = None,
        default_connection_method: str = "mcp",
        default_approval_mode: str = "never_require",
        iss: Optional[str] = None,
        sub: Optional[str] = None,
    ) -> "MCPToolConfig":
        base_url = os.getenv(base_url_env)
        connection_method = os.getenv(
            connection_method_env, default_connection_method
        )
        approval_mode = os.getenv(approval_mode_env, default_approval_mode)

        if not base_url:
            raise ValueError(
                f"Missing required MCP env: {base_url_env}. Set it in your environment/.env"
            )

        return cls(
            name=name,
            base_url=base_url,
            connection_method=connection_method,
            approval_mode=approval_mode,
            bearer_token_env=bearer_token_env,
            private_key_env=private_key_env,
            default_connection_method=default_connection_method,
            default_approval_mode=default_approval_mode,
            iss=iss,
            sub=sub,
        )

    # ----- helpers -----
    @property
    def url(self) -> str:
        return _compose_mcp_url(self.base_url, self.connection_method)

    def make_headers(self) -> Dict[str, str]:
        """
        NOTE:
          - static token only
          - JWT 生成は mcp.py 側の `make_headers(cfg: MCPToolConfig)` を利用してください
        """
        if self.bearer_token_env:
            tok = (
                (os.getenv(self.bearer_token_env) or "")
                .strip()
                .strip('"')
                .strip("'")
            )
            if tok:
                return {"Authorization": f"Bearer {tok}"}

        if self.private_key_env:
            raise RuntimeError(
                "JWT header generation is provided in mcp.make_headers(cfg). "
                "Use that helper instead of MCPToolConfig.make_headers() when private_key_env is set."
            )

        raise RuntimeError(
            f"No valid auth for {self.name}. Set {self.bearer_token_env or '<STATIC_TOKEN_ENV>'} "
            f"or {self.private_key_env or '<PRIVATE_KEY_ENV>'} in environment."
        )


@dataclass
class MagentoConfig(MCPToolConfig):
    @classmethod
    def from_env(cls) -> "MagentoConfig":
        return cls(
            **MCPToolConfig.from_env(
                name="Magento MCP",
                base_url_env="MAGENTO_TOOL_URL",
                connection_method_env="MAGENTO_TOOL_CONNECTION_METHOD",
                approval_mode_env="MAGENTO_TOOL_APPROVAL_MODE",
                bearer_token_env="MAGENTO_TOOL_BEARER_TOKEN",
                private_key_env="MAGENTO_PRIVATE_KEY",
                default_connection_method="mcp",
                default_approval_mode="never_require",
                iss=os.getenv("MAGENTO_MCP_JWT_ISS"),
                sub=os.getenv("MAGENTO_MCP_JWT_SUB"),
            ).__dict__
        )


@dataclass
class KnowledgeBaseConfig(MCPToolConfig):
    @classmethod
    def from_env(cls) -> "KnowledgeBaseConfig":
        return cls(
            **MCPToolConfig.from_env(
                name="KnowledgeBase MCP",
                base_url_env="KB_TOOL_URL",
                connection_method_env="KB_TOOL_CONNECTION_METHOD",
                approval_mode_env="KB_TOOL_APPROVAL_MODE",
                bearer_token_env="KB_TOOL_BEARER_TOKEN",
                private_key_env="KB_PRIVATE_KEY",
                default_connection_method="mcp",
                default_approval_mode="never_require",
                iss=os.getenv("KNOWLEDGEBASE_MCP_JWT_ISS"),
                sub=os.getenv("KNOWLEDGEBASE_MCP_JWT_SUB"),
            ).__dict__
        )


# Global cached config instances
@lru_cache(maxsize=1)
def get_langfuse_config() -> LangfuseConfig:
    """Get cached Langfuse configuration."""
    return LangfuseConfig.from_env()


@lru_cache(maxsize=1)
def get_azure_openai_config() -> AzureOpenAIConfig:
    """Get cached Azure OpenAI configuration (for agents via LiteLLM)."""
    return AzureOpenAIConfig.from_env()


@lru_cache(maxsize=1)
def get_mem0_azure_openai_config() -> Mem0AzureOpenAIConfig:
    """Get cached mem0 Azure OpenAI configuration (direct endpoint)."""
    return Mem0AzureOpenAIConfig.from_env()


@lru_cache(maxsize=1)
def get_azure_foundry_config() -> AzureAIFoundryConfig:
    """Get cached Azure AI Foundry configuration."""
    return AzureAIFoundryConfig.from_env()


@lru_cache(maxsize=1)
def get_azure_search_config() -> AzureSearchConfig:
    """Get cached Azure AI Search configuration."""
    return AzureSearchConfig.from_env()


@lru_cache(maxsize=1)
def get_aoai_embedding_config() -> AzureOpenAIEmbeddingConfig:
    """Get cached Azure OpenAI embedding configuration (deprecated)."""
    return AzureOpenAIEmbeddingConfig.from_env()


@lru_cache(maxsize=1)
def get_magento_config() -> MagentoConfig:
    return MagentoConfig.from_env()


@lru_cache(maxsize=1)
def get_kb_config() -> KnowledgeBaseConfig:
    return KnowledgeBaseConfig.from_env()
