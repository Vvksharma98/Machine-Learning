"""Langfuse utilities shared across agents."""

from functools import lru_cache

from langfuse import Langfuse

from .config import get_langfuse_config


@lru_cache(maxsize=1)
def get_langfuse_client() -> Langfuse:
    """Get cached Langfuse client.

    Returns a singleton Langfuse client instance to be reused
    across all agents.
    """
    config = get_langfuse_config()
    return Langfuse(
        public_key=config.public_key,
        secret_key=config.secret_key,
        host=config.host,
    )


def get_prompt(prompt_name: str, version: str | None = None) -> str:
    """Get prompt from Langfuse.

    Args:
        prompt_name: Name of the prompt to fetch.
        version: Specific version to fetch. Uses latest if None.

    Returns:
        Prompt text.

    Raises:
        ValueError: If prompt cannot be fetched.
    """
    client = get_langfuse_client()
    try:
        prompt = client.get_prompt(prompt_name, version=version)
        return prompt.prompt
    except Exception as e:
        raise ValueError(
            f"Failed to fetch prompt '{prompt_name}' from Langfuse: {e}"
        ) from e
