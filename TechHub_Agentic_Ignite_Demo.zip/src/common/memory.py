"""Helpers for configuring mem0 long-term memory."""

from mem0 import AsyncMemory
from mem0.configs.base import MemoryConfig
from agent_framework.mem0 import Mem0Provider

from .config import (
    get_mem0_azure_openai_config,
    get_azure_search_config,
)


def build_mem0_config() -> dict:
    """Build configuration dictionary for mem0."""
    search_cfg = get_azure_search_config()
    mem0_cfg = get_mem0_azure_openai_config()

    return {
        "vector_store": {
            "provider": "azure_ai_search",
            "config": {
                "service_name": search_cfg.service_name,
                "api_key": search_cfg.api_key,
                "collection_name": search_cfg.collection_name,
                "embedding_model_dims": search_cfg.embedding_dims,
            },
        },
        "embedder": {
            "provider": "azure_openai",
            "config": {
                "model": mem0_cfg.embedding_deployment,
                "embedding_dims": 1536,
                "azure_kwargs": {
                    "api_version": mem0_cfg.api_version,
                    "azure_deployment": mem0_cfg.embedding_deployment,
                    "azure_endpoint": mem0_cfg.endpoint,
                    "api_key": mem0_cfg.api_key,
                },
            },
        },
        "llm": {
            "provider": "azure_openai",
            "config": {
                "model": mem0_cfg.chat_deployment,
                "azure_kwargs": {
                    "api_version": mem0_cfg.api_version,
                    "azure_deployment": mem0_cfg.chat_deployment,
                    "azure_endpoint": mem0_cfg.endpoint,
                    "api_key": mem0_cfg.api_key,
                },
            },
        },
        "version": "v1.1",
    }


def build_mem0_client() -> AsyncMemory:
    """Create an AsyncMemory client configured for Azure resources.

    Note: This is synchronous initialization. AsyncMemory() constructor
    is synchronous, not AsyncMemory.from_config() which is async.
    """
    config_dict = build_mem0_config()
    memory_config = MemoryConfig(**config_dict)
    return AsyncMemory(config=memory_config)


def build_mem0_provider(
    user_id: str,
    mem0_client: AsyncMemory | None = None,
) -> Mem0Provider:
    """Create a Mem0Provider for agent_framework integration.

    Args:
        user_id: User ID for scoping memories.
        mem0_client: Optional existing mem0 client. If not provided, creates new one.

    Returns:
        Configured Mem0Provider instance.
    """
    if mem0_client is None:
        mem0_client = build_mem0_client()

    provider = Mem0Provider(
        mem0_client=mem0_client,
        user_id=user_id,
        scope_to_per_operation_thread_id=False,
    )

    return provider
