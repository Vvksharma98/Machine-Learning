"""Launch the retail agents with DevUI."""

import logging
import sys
from pathlib import Path

from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv(override=True)

# Add src to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root / "src"))

from agent_framework.devui import serve

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(message)s")
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger(__name__)


def load_agents(user_id: str):
    """Load agents with user_id for mem0 support.

    Args:
        user_id: User ID for mem0 memory
    """
    from common.memory import build_mem0_client

    entities = []

    # Create shared mem0 client
    mem0_client = build_mem0_client()

    # Load Michael agent with user_id
    try:
        from agents.customer_service_agent_Michael.agent import MichaelAgent

        michael_instance = MichaelAgent(
            user_id=user_id, mem0_client=mem0_client
        )
        entities.append(michael_instance.agent)
        logger.info(f"✓ Loaded Michael agent (user_id={user_id})")
    except Exception as e:
        logger.error(f"✗ Failed to load Michael agent: {e}")
        import traceback

        traceback.print_exc()
        raise

    return entities


def main():
    """Main entry point."""
    try:
        # Get user_id from environment
        import os

        user_id = os.getenv("DEFAULT_USER_ID", "default_user")

        logger.info(f"\n🔍 Configuration:")
        logger.info(f"  user_id: {user_id}")

        # Load agents with user_id
        entities = load_agents(user_id=user_id)

        logger.info("\n🚀 Starting Retail Agents with DevUI")
        logger.info("Available at: http://localhost:8080")
        logger.info(f"Memory enabled for user: {user_id}")

        # Launch DevUI server with tracing enabled
        serve(
            entities=entities,
            port=8080,
            auto_open=True,
            tracing_enabled=True,  # ← トレーシングは有効
        )
    except KeyboardInterrupt:
        logger.info("\n\nShutting down...")
    except Exception as e:
        logger.error(f"\n✗ Fatal error: {e}")
        import traceback

        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
